
exports.order_home=(req,res)=>{
    res.send("Order Home Page");
}
exports.order_id=(req,res)=>{
    res.send("Order id");
}
exports.order_pending=(req,res)=>{
    res.send("Pending Orders");
}