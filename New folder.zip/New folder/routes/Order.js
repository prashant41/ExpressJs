const express=require('express')
const router=express.Router();
const controller=require("../controller/controls.js")

//APIs
//Controller instance calling

router.get("/order",controller.order_home);
router.get("/order/id",controller.order_id);
router.get("/order/pending",controller.order_pending);

module.exports=router;