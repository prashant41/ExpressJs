require('dotenv').config()
const express=require('express')
const app=express()
const port=process.env.PORT;
//Import Order Router
const order=require('./routes/Order.js')

//ROUTE Addess

const route=require("./routes/Order.js")
app.use('/',route);


app.listen(port,()=>{
    console.log(`Server is connected at port ${port}`);
})